const movies = [
    {"title": "Star Wars III. rész A Sith-ek bosszúja", "director": "George Lucas", "year": 2005, "oscar": "nincs"},
    {"title": "Oppenheimer", "director": "Christopher Nolan", "year": 2023, "oscar": "van"},
    {"title": "Megfojtott virágok", "director": "Martin Scorsese", "year": 2023, "oscar": "van"},
]

export default movies